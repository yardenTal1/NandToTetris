"""
writes the assembly code that implements the parsed command
"""

class CodeWriter:

	C_PUSH = "push"
	C_POP = "pop"

	def __init__(self, output_file):
		"""
		open the output file and gets ready to write into it.
		:param output_file: the output file
		"""
		self.file = output_file
		self.name_file = ""
		self.counter = 0
		self.curr_function = "Sys.init"
		self.return_counter = 0
		self.writeInit()

	def setFileName(self, name):
		"""
		Informs the code writer that the translation of a new VM file is started.
		:param name:  the file name(string)
		"""
		self.name_file = name

	def writeInit(self):
		"""
		Writes the assembly code that effects the VM initialization (also called bootstrap code).
		This code should be placed in the ROM beginning in address 0x0000.
		"""
		self.file.write("@256\n")
		self.file.write("D=A\n")
		self.file.write("@SP\n")
		self.file.write("M=D\n")
		self.writeCall("Sys.init", 0)

	def popToD(self, dest):
		self.file.write(dest + "\n")
		self.file.write("D=M\n")
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=D\n")

	def pushZero(self):
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=0\n")

	def writeLabel(self, labelName):
		"""
		Writes the assembly code that is the translation of the given label command.
		:param labelName:
		"""
		self.file.write("(" + self.curr_function + "$." + labelName + ")\n")

	def writegoto (self, labelName):
		"""
		Writes assembly code that effects the goto command.
		:param labelName:
		"""
		self.file.write("@" + self.curr_function + "$." + labelName + "\n")
		self.file.write("0;JMP\n")

	def writeIf (self, labelName):
		"""
		Writes assembly code that effects the if-goto command.
		:param labelName:
		"""
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.file.write("@" + self.curr_function + "$." + labelName + "\n")
		self.file.write("D;JNE\n") # if D != 0 then jump (0==false)

	def writeCall(self, functionName, nArgs):
		"""
		Writes assembly code that effects the call command.
		:param functionName: function name
		:param nArgs: the number of argument
		"""

		self.file.write("@" + self.curr_function + "$ret." + str(self.return_counter) +"\n")
		self.file.write("D=A\n")
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=D\n")
		self.incrementSP()

		#sava LCL, ARG, THIS., THAT of the caller
		self.popToD("@LCL")
		self.incrementSP()
		self.popToD("@ARG")
		self.incrementSP()
		self.popToD("@THIS")
		self.incrementSP()
		self.popToD("@THAT")
		self.incrementSP()

		#Repositions ARG
		self.file.write("@" + str(nArgs) + "\n")
		self.file.write("D=A\n")
		self.file.write("@5\n")
		self.file.write("D=A+D\n")
		self.file.write("@SP\n")
		self.file.write("D=M-D\n")
		self.file.write("@ARG\n")
		self.file.write("M=D\n")

		#Repositions LCL
		self.file.write("@SP\n")
		self.file.write("D=M\n")
		self.file.write("@LCL\n")
		self.file.write("M=D\n")

		#Transfer control to the called function
		self.file.write("@" + functionName + "\n")
		self.file.write("0;JMP\n")

		#Deaclares a label for the return address
		self.file.write("(" + self.curr_function + "$ret." + str(self.return_counter) + ")" + "\n")
		self.return_counter += 1

	def restoresSegmentCaller(self, seg):
		self.file.write("@R13\n")
		self.file.write("M=M-1\n")
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.file.write("@" + seg +"\n")
		self.file.write("M=D\n")

	def writeReturn(self):
		"""
		Writes assembly code that effects the return command.
		"""
		self.file.write("@LCL\n")
		self.file.write("D=M\n")
		self.file.write("@R13\n") #R13 = endFrame
		self.file.write("M=D\n")
		self.file.write("D=M\n")

		# gets the return address
		self.file.write("@5\n")
		self.file.write("D=D-A\n") # D = *endframe - 5
		self.file.write("A=D\n")
		self.file.write("D=M\n")
		self.file.write("@R14\n") # retAddr
		self.file.write("M=D\n")
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")  # the return value

		# repositions the return value for the caller
		self.file.write("@ARG\n")
		self.file.write("A=M\n")
		self.file.write("M=D\n")  # put in ARG the return value

		# repositions SP of the caller
		self.file.write("@ARG\n")
		self.file.write("D=M+1\n")
		self.file.write("@SP\n")
		self.file.write("M=D\n")

		#Restores THAT,THIS,ARG,LCL of the caller
		self.restoresSegmentCaller("THAT")
		self.restoresSegmentCaller("THIS")
		self.restoresSegmentCaller("ARG")
		self.restoresSegmentCaller("LCL")

		#goto retAddr
		self.file.write("@R14\n")
		self.file.write("A=M\n")
		self.file.write("0;JMP\n")


	def writeFunction(self, functionName, numLocals):
		"""
		Writes assembly code that effects the function command.
		:param functionName:
		:param numLocals:
		"""
		self.curr_function = functionName
		self.return_counter += 1
		self.file.write("(" + functionName + ")\n")
		for i in range(int(numLocals)):
			self.pushZero()
			self.incrementSP()


	def writeArithmetic(self, command):
		"""
		writes to the output file the assembly code that implements the given arithmetic command.
		@:param command arithmetic command (string)
		"""
		if command == "gt" or command == "lt" or command == "eq":
			self.writeBool(command)
		elif command == "add":
			self.writeLogicExpression("+")
		elif command == "sub":
			self.writeLogicExpression("-")
		elif command == "or":
			self.writeLogicExpression("|")
		elif command == "and":
			self.writeLogicExpression("&")
		elif command == "neg":
			self.negAndNot("-")
		elif command == "not":
			self.negAndNot("!")


	def decrementSP(self):
		"""
		produces the assembly lines for decrement SP on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("M=M-1\n")

	def incrementSP(self):
		"""
		produces the assembly lines for increment SP on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("M=M+1\n")

	def pushTrue(self):
		"""
		produces the assembly lines for true on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=-1\n")

	def pushFalse(self):
		"""
		produces the assembly lines for false on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=0\n")

	def writeLogicExpression(self, sign):
		"""
		produces the assembly lines for sum, sub, and, or operators on the stack variables
		:param sign: + , -, &, |
		"""
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=M" + sign + "D\n")
		self.incrementSP()

	def negAndNot(self, sign):
		"""
		produces the assembly lines for neg and not operators on the stack variables
		:param sign: !, -
		"""
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=" + sign + "M\n")
		self.incrementSP()

	def writeBool(self, command):
		"""
		produces the assembly lines for boolean operators (> = < ) on the stack variables
		:param command:
		:return:
		"""
		self.file.write("@SP\n")
		self.file.write("A=M-1\n")
		self.file.write("D=M\n")
		self.file.write("@R15\n")
		self.file.write("M=D\n")
		self.file.write("@R13\n")
		self.file.write("M=!D\n")
		self.decrementSP()
		self.file.write("@SP\n")
		self.file.write("A=M-1\n")
		self.file.write("D=M\n")
		self.file.write("@R14\n")
		self.file.write("M=D\n")
		self.file.write("@R14\n")
		self.file.write("M=!D\n")
		self.file.write("@R15\n")
		self.file.write("D=D&M\n")
		self.file.write("@R15\n")
		self.file.write("M=D\n")
		self.file.write("@R13\n")
		self.file.write("D=M\n")
		self.file.write("@R14\n")
		self.file.write("D=M&D\n")
		self.file.write("@R14\n")
		self.file.write("M=D\n")
		self.file.write("@R15\n")
		self.file.write("D=M|D\n")

		self.file.write("@SAMESIGN" + command.upper() + str(self.counter) + "\n")
		self.file.write("D;JLT\n")

		self.file.write("(DIFRRENTSIGN" + command.upper() + str(self.counter) + ")\n")
		if command == 'eq':
			self.decrementSP()
			self.file.write("@SP\n")
			self.file.write("A=M\n")
			self.file.write("M=0\n")
			self.incrementSP()
			self.file.write("@END" + str(self.counter) +"\n")
			self.file.write("0;JMP\n")
		elif command == 'lt':
			self.decrementSP()
			self.file.write("A=M\n")
			self.file.write("D=M\n") #X
			self.file.write("@TRUE" + str(self.counter) + "\n")
			self.file.write("D;JLT\n")
			self.file.write("@FALSE" + str(self.counter) + "\n")
			self.file.write("D;JGE\n")

		elif command == 'gt':
			self.decrementSP()
			self.file.write("A=M\n")
			self.file.write("D=M\n") #X
			self.file.write("@FALSE" + str(self.counter) + "\n")
			self.file.write("D;JLT\n")
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JGE\n")


		self.file.write("(SAMESIGN" + command.upper() + str(self.counter) + ")\n")
		if command == 'eq':
			self.file.write("@SP\n")
			self.file.write("A=M\n")
			self.file.write("D=M\n") #D=Y
			self.decrementSP()
			self.file.write("A=M\n")
			self.file.write("D=M-D\n") #D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JEQ\n")


		elif command == 'lt':
			self.file.write("@SP\n")
			self.file.write("A=M\n")
			self.file.write("D=M\n") #D=Y
			self.decrementSP()
			self.file.write("A=M\n")
			self.file.write("D=M-D\n")  # D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JLT\n")

		elif command == 'gt':
			self.file.write("@SP\n")
			self.file.write("A=M\n")
			self.file.write("D=M\n") #D=Y
			self.decrementSP()
			self.file.write("A=M\n")
			self.file.write("D=M-D\n")  # D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JGT\n")

		self.file.write("(FALSE" + str(self.counter) + ")\n")
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=0\n")
		self.incrementSP()
		self.file.write("@END" + str(self.counter) + "\n")
		self.file.write("0;JMP\n")
		self.file.write("(TRUE" + str(self.counter) + ")\n")
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=-1\n")
		self.incrementSP()
		self.file.write("@END" + str(self.counter) + "\n")
		self.file.write("0;JMP\n")
		self.file.write("(END" + str(self.counter) + ")\n")
		self.counter += 1

	def writePushPop(self, command, segment, index):
		"""
		writes to the output file the assembly code that implements the given command, where command is either
		C_PUSH or C_POP
		:param command:  C_PUSH or C_POP command (string)
		:param segment: segment to write to (string)
		:param index: location in the segment (int)
		"""
		index = int(index)
		four_similar_segments ={"local" : "@LCL", "argument" : "@ARG", "this" : "@THIS", "that": "@THAT"}
		if command == self.C_PUSH:
			if segment in four_similar_segments:
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=A\n")
				self.file.write(four_similar_segments[segment] + "\n")
				self.file.write("D=D+M\n")
				self.file.write("A=D\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "constant":
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=A\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "temp":
				self.file.write("@" + str(index + 5) + "\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "static":
				self.file.write("@" + self.name_file + "." + str(index) + "\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "pointer":
				if index == 0:
					self.file.write("@THIS\n")
				elif index == 1:
					self.file.write("@THAT\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()

		if command == self.C_POP:
			if segment in four_similar_segments:
				self.file.write(four_similar_segments[segment] + "\n")
				self.file.write("D=M\n")
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=D+A\n")
				self.file.write("@R13\n") #general purpose registers
				self.file.write("M=D\n")
				self.decrementSP()
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@R13\n")  # general purpose registers
				self.file.write("A=M\n")
				self.file.write("M=D\n")

			elif segment == "temp":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@" + str(index + 5) + "\n")
				self.file.write("M=D\n")
			elif segment == "static":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@" + self.name_file + "." + str(index) + "\n")
				self.file.write("M=D\n")
			elif segment == "pointer":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				if index == 0:
					self.file.write("@THIS\n")
				elif index == 1:
					self.file.write("@THAT\n")
				self.file.write("M=D\n")


	def close(self):
		"""
		closes the output file
		"""
		self.file.close()