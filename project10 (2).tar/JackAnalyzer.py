from CompilationEngine import *
from JackTokenizer import *
import sys
import os


def translate_file(input_file, output_file):
	jack_tokenizer = JackTokenizer(input_file)
	compilation_engine = CompilationEngine(jack_tokenizer, output_file)
	compilation_engine.compile_class()
	input_file.close()
	output_file.close()


def main(file_path):
	"""
	for each file - create jack tokenizer, create an output file, create and uses compilation
	engine to compile the input into the output file.
	"""
	if os.path.isdir(file_path):  # if the input is a dir
		for file in os.listdir(file_path):
			if file.endswith(".jack"):
				input_file = open(file_path + '/' + file, "r")
				output_file = open(os.path.splitext(file_path)[0] + '/' + os.path.splitext(file)[
					0] + '.xml', "w")
				translate_file(input_file, output_file)
	elif os.path.isfile(file_path):  # if the input is a file
		if file_path.endswith(".jack"):
			input_file = open(file_path, "r")
			output_file = open(os.path.splitext(file_path)[0] + '.xml', "w")
			translate_file(input_file, output_file)


if __name__ == "__main__":
	file_abs_path = os.path.abspath(sys.argv[1])
	main(file_abs_path)



