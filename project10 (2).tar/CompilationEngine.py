from JackTokenizer import *


class CompilationEngine:
	"""
	this class generates the compiler's output.
	"""

	OP = ["+", "-", "*", "/", "&", "|", "<", ">", "="]
	CONST_KEYWORD = ["true", "false", "null", "this"]
	UNARY_OP = ["-", "~"]

	def __init__(self, tokenizer, output_file):
		"""
		creates a new compilation engine with the given input and output.
		"""
		self.tokenizer = tokenizer
		self.output_file = output_file

	def print_keyword(self, keyword):
		"""
		print to the output file keyword
		"""
		self.output_file.write("<keyword> " + keyword + " </keyword>\n")

	def print_symbol(self, symbol):
		"""
		print to the output file symbol
		"""
		self.output_file.write("<symbol> " + symbol + " </symbol>\n")

	def print_identifier(self, identifier):
		"""
		print to the output file identifier
		"""
		self.output_file.write("<identifier> " + identifier + " </identifier>\n")

	def compile_class(self):
		"""
		compiles a complete class
		"""
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile class
		self.output_file.write("<class>\n")
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile class name
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile "{"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile var dec if has
		while self.tokenizer.token_type() == "KEYWORD" and (self.tokenizer.keyWord() == "static"
														or self.tokenizer.keyWord() == "field"):
			self.compile_class_var_dec()
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile subroutine declaration
		while self.tokenizer.token_type() == "KEYWORD" and (self.tokenizer.keyWord() == "constructor"
				or self.tokenizer.keyWord() == "function" or self.tokenizer.keyWord() == "method"):
			self.compile_subroutine_dec()
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile "}"
		self.print_symbol(self.tokenizer.symbol())
		self.output_file.write("</class>\n")

	def compile_class_var_dec(self):
		"""
		compiles a static variable declaration, or a field declaration
		"""
		self.output_file.write("<classVarDec>\n")

		# compile static / field
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile type
		self.compile_type()

		# compile var name
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
			# compile ","
			self.print_symbol(self.tokenizer.symbol())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			# compile var name
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile ";"
		self.print_symbol(self.tokenizer.symbol())
		self.output_file.write("</classVarDec>\n")

	def compile_subroutine_dec(self):
		"""
		compiles a complete method, function, or constructor
		"""
		self.output_file.write("<subroutineDec>\n")

		# compile constructor / function / method
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile void / type
		if self.tokenizer.token_type() == "KEYWORD":  # void or type = int / char / boolean
			self.print_keyword(self.tokenizer.keyWord())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
		else:  # class name
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile subroutine name
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile parameters list
		self.compile_subroutine_list()

		# compile subroutine body
		self.compile_subroutine_body()

		self.output_file.write("</subroutineDec>\n")

	def compile_parameter(self):
		"""
		compiles a parameter
		"""
		if self.tokenizer.token_type() == "KEYWORD":
			self.print_keyword(self.tokenizer.keyWord())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
		else:
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

	def compile_subroutine_list(self):
		"""
		compiles a (possibly empty) parameter list. does not handle the enclosing "()"
		:return:
		"""
		# compile "("
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.output_file.write("<parameterList>\n")

		if self.tokenizer.symbol() != ")":
			self.compile_parameter()
			while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_parameter()

		self.output_file.write("</parameterList>\n")

		# compile ")"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

	def compile_subroutine_body(self):
		"""
		compiles a subroutine's body
		"""
		self.output_file.write("<subroutineBody>\n")
		# compile "{"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile varDec
		while self.tokenizer.token_type() == "KEYWORD" and self.tokenizer.keyWord() == "var":
			self.compile_var_dec()

		# compile statements
		self.compile_statements()

		# compile "}"
		# if self.tokenizer.has_more_tokens():
		# 	self.tokenizer.advance()
		self.print_symbol(self.tokenizer.symbol())

		self.output_file.write("</subroutineBody>\n")

	def compile_type(self):
		"""
		compiles a type variable
		"""
		if self.tokenizer.token_type() == "KEYWORD":
			self.print_keyword(self.tokenizer.keyWord())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
		else:
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

	def compile_var_dec(self):
		"""
		compiles a var declaration
		"""
		self.output_file.write("<varDec>\n")

		# compile var
		self.print_keyword(self.tokenizer.keyWord())

		# compile type
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.compile_type()  # (compile type advance to the next toekn)

		# compile var name
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
			self.print_symbol(self.tokenizer.symbol())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile ";"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.output_file.write("</varDec>\n")

	def compile_statements(self):
		"""
		compiles a sequence of statements. does not handle the enclosing "()"
		"""
		self.output_file.write("<statements>\n")
		while self.tokenizer.token_type() == "KEYWORD":
			if self.tokenizer.keyWord() == "let":
				self.compile_let()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			if self.tokenizer.keyWord() == "if":
				self.compile_if()
				# the advance is inside the function compile if
			if self.tokenizer.keyWord() == "while":
				self.compile_while()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			if self.tokenizer.keyWord() == "do":
				self.compile_do()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			if self.tokenizer.keyWord() == "return":
				self.compile_return()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
		self.output_file.write("</statements>\n")

	def compile_let(self):
		"""
		compiles a let statement
		"""
		# compile let
		self.output_file.write("<letStatement>\n")
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile varName
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		if self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == "[":
			# compile [
			self.print_symbol(self.tokenizer.symbol())
			# compile expression
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			self.compile_expression()
			# compile ]
			self.print_symbol(self.tokenizer.symbol())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile =
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile expression
		self.compile_expression()

		# compile ;
		self.print_symbol(self.tokenizer.symbol())
		self.output_file.write("</letStatement>\n")

	def compile_if(self):
		"""
		compiles an id statement, possibly with a trailing else clause
		"""
		# compile while
		self.output_file.write("<ifStatement>\n")
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile "("
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile expression
		self.compile_expression()

		# compile ")"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile "{"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile statements
		self.compile_statements()

		# compile "}"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile else
		if self.tokenizer.token_type() == "KEYWORD" and self.tokenizer.keyWord() == "else":
			self.print_keyword(self.tokenizer.keyWord())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			# compile "{"
			self.print_symbol(self.tokenizer.symbol())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			# compile statements
			self.compile_statements()
			# compile "}"
			self.print_symbol(self.tokenizer.symbol())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		self.output_file.write("</ifStatement>\n")

	def compile_while(self):
		"""
		compiles a while statement
		"""
		# compile while
		self.output_file.write("<whileStatement>\n")
		self.print_keyword(self.tokenizer.keyWord())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile "("
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile expression
		self.compile_expression()

		# compile ")"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile "{"
		self.print_symbol(self.tokenizer.symbol())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile statements
		self.compile_statements()

		# compile "}"
		self.print_symbol(self.tokenizer.symbol())
		self.output_file.write("</whileStatement>\n")

	def compile_do(self):
		"""
		compiles a do statement
		"""
		# compile do
		self.output_file.write("<doStatement>\n")
		self.print_keyword(self.tokenizer.keyWord())

		# compile subroutine name / class name / var name
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.print_identifier(self.tokenizer.identifier())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		if self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ".":
			# compile "."
			self.print_symbol(self.tokenizer.symbol())
			# compile subroutine name
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile "("
		self.print_symbol(self.tokenizer.symbol())

		# compile expression
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.compile_expression_list()

		# compile ")"
		self.print_symbol(self.tokenizer.symbol())

		# compile ;
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.print_symbol(self.tokenizer.symbol())

		self.output_file.write("</doStatement>\n")

	def compile_return(self):
		"""
		compiles a return statement
		"""
		# compile return
		self.output_file.write("<returnStatement>\n")
		self.print_keyword(self.tokenizer.keyWord())

		# compile expression
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		if self.tokenizer.keyWord() != ";":
			self.compile_expression()

		# compile ;
		self.print_symbol(self.tokenizer.symbol())
		self.output_file.write("</returnStatement>\n")

	def compile_expression(self):
		"""
		compiles an expression
		"""
		# compile expression
		self.output_file.write("<expression>\n")

		# compile term
		self.compile_term()

		# compile (op term)*
		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() in self.OP:
			if self.tokenizer.symbol() == "<":
				self.print_symbol("&lt;")
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.symbol() == ">":
				self.print_symbol("&gt;")
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.symbol() == "&":
				self.print_symbol("&amp;")
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			else:
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()

			self.compile_term()

		self.output_file.write("</expression>\n")

	def compile_term(self):
		"""
		compiles an term. if the current token is an identifier, the routine must distinguish
		btween a variable, an array entry, or a subroutine call. a single look-ahead token,
		which may be ont of "[","(", or ".", suffices to distinguish between the possibilities.
		any other token is not part of this trem and should be advanced over
		"""
		self.output_file.write("<term>\n")

		# compile integer constant
		if self.tokenizer.token_type() == "INT_CONST":
			self.output_file.write("<integerConstant> " + self.tokenizer.intVal() + " </integerConstant>\n")
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile string constant
		elif self.tokenizer.token_type() == "STRING_CONST":
			string_token = self.tokenizer.stringVal()
			string_token = string_token.replace("&", "&amp;")
			string_token = string_token.replace(">", "&gt;")
			string_token = string_token.replace("<", "&lt;")
			self.output_file.write("<stringConstant> " + string_token + " </stringConstant>\n")
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile keyword constant
		elif self.tokenizer.token_type() == "KEYWORD" and self.tokenizer.keyWord() in \
														 self.CONST_KEYWORD:
			self.print_keyword(self.tokenizer.keyWord())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile var name / varName[expression] / subroutine call
		elif self.tokenizer.token_type() == "IDENTIFIER":
			self.print_identifier(self.tokenizer.identifier())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			if self.tokenizer.token_type() == "SYMBOL":
				if self.tokenizer.symbol() == "[":  # varName[expression]
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
					self.compile_expression()
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
				elif self.tokenizer.symbol() == "(":  # subroutineName(expressionList)
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
					self.compile_expression_list()
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
				elif self.tokenizer.symbol() == ".":  # (className|varName).subroutineName(expressionList)
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
					self.print_identifier(self.tokenizer.identifier())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
					self.compile_expression_list()
					self.print_symbol(self.tokenizer.symbol())
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
		elif self.tokenizer.token_type() == "SYMBOL":
			if self.tokenizer.symbol() == "(":  # compile (expression)
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_expression()
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.symbol() in self.UNARY_OP:  # compile unary op term
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_term()
		self.output_file.write("</term>\n")

	def compile_expression_list(self):
		"""
		compiles a (possibly empty) comma-separated list of expressions
		"""
		self.output_file.write("<expressionList>\n")

		if (self.tokenizer.token_type() == "INT_CONST") or (self.tokenizer.token_type() ==
			"STRING_CONST") or (self.tokenizer.token_type() == "KEYWORD") or (
				self.tokenizer.token_type() == "IDENTIFIER") or (self.tokenizer.token_type() ==
				"SYMBOL" and (self.tokenizer.symbol() == "(" or self.tokenizer.symbol() in
			self.UNARY_OP)):
			# compile expression
			self.compile_expression()

			while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
				self.print_symbol(self.tokenizer.symbol())
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_expression()

		self.output_file.write("</expressionList>\n")
