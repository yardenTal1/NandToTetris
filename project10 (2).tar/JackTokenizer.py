class JackTokenizer:
	"""
	The class that removes all comments and white space from the input stream and
	breaks it into Jack-language tokens, as specified by the Jack grammar.
	"""

	KEYWORDS = ['class', 'method', 'function', 'constructor', 'int', 'boolean', 'char',
				'void', 'var', 'static',  'field', 'let', 'do', 'if', 'else', 'while',
				'return', 'true', 'false', 'null',  'this']
	SYMBOLS = ['{', '}', '(', ')', '[', ']', '.', ',', ';', '+', '-', '*', '/', '&', '|',
			   '<', '>', '=', '~']
	TOKEN_TYPE = {"int": "INT_CONST", "string": "STRING_CONST", "id": "IDENTIFIER",
				  "symb": "SYMBOL", "key": "KEYWORD"}

	def __init__(self, input_file):
		"""
		The constractur that opens the input file/stream and gets ready to tokenize it
		:param input_file: input file
		"""
		self.file = input_file
		self.curr_token = ""
		self.curr_token_type =""
		self.next_token_type = ""
		self.next_token = self.get_next_token()

	def has_more_tokens(self):
		"""
		are there more tokens in the input
		:return: true if has more tokens, otherwise return false
		"""
		if (self.next_token != ""):
			return True
		return False

	def advance(self):
		"""
		gets the next token from thr input, and makes it the current token. this method should be
		 called only if hasMoreTokens is true.
		Initially there is no current token.
		"""
		self.curr_token = self.next_token
		self.curr_token_type = self.next_token_type
		self.next_token = self.get_next_token()

	def get_next_token(self):
		"""
		A function that returns the next token and updates its type
		:return: the next token
		"""
		self.clean_the_current_token()
		current_token = self.file.read(1)
		if current_token == '': # end of file
			self.next_token = ""
			return current_token
		if current_token in self.SYMBOLS:
			self.set_curr_type(self.TOKEN_TYPE.get("symb"))
			return current_token
		elif current_token == "\"":  # start with " - so its a string
			current_token = self.file.read(1)
			while current_token[-1] != "\"":
				current_token += self.file.read(1)
			current_token = current_token[0:-1] # take the string without "
			self.set_curr_type(self.TOKEN_TYPE.get("string"))
			return current_token
		current_position = self.file.tell()

		# if the current token is more then only one char
		while (current_token[-1] != "\\" and not current_token[-1].isspace()
			   and current_token[-1] not in self.SYMBOLS): # escaped characters are 2 separate characters
			current_position = self.file.tell()
			current_token += self.file.read(1)
		if current_token[-1] == "\\": # Escaped characters should not be interpreted.
			self.file.read(1)
		else:
			self.file.seek(current_position)
		current_token = current_token[:-1]
		if current_token in self.KEYWORDS:
			self.set_curr_type(self.TOKEN_TYPE.get("key"))
			return current_token
		elif current_token.isdigit():
			self.set_curr_type(self.TOKEN_TYPE.get("int"))
			return current_token
		else:
			self.set_curr_type(self.TOKEN_TYPE.get("id"))
			return current_token

	def set_curr_type(self, type):
		"""
		A function that set the type for the next token
		:param type: The type to update
		"""
		self.next_token_type = type

	def peek_next(self):
		"""
		A function that returns the value of the next token without moving the pointer to it
		:return: next_char
		"""
		current_position = self.file.tell()
		next_char = self.file.read(1)
		self.file.seek(current_position)
		return next_char

	def clean_the_current_token(self):
		"""
		A function that clear the current token from spaces and comments
		"""
		curr_position = self.file.tell()
		curr_char = self.file.read(1)

		while curr_char.isspace():  # clean spaces
			curr_position = self.file.tell()
			curr_char = self.file.read(1)
		if curr_char in self.SYMBOLS and curr_char != "/":
			self.file.seek(curr_position)
			return

		if curr_char == "/" and self.peek_next() == "/":  # its end of line comment //
			self.file.readline()
		elif curr_char == "/" and self.peek_next() == "*":  # its a start of comment /*
			self.file.read(1)
			curr_char = self.file.read(1)
			if curr_char == "*" and self.peek_next() != "/":  # the comment that start with /**
				curr_char = self.file.read(1)
			while curr_char != "*" or self.peek_next() != "/":  # the comment
				curr_char = self.file.read(1)
			self.file.read(1)
			curr_position = self.file.tell()
			self.file.seek(curr_position)
		elif curr_char == "/":  # symbol divide
			self.file.seek(curr_position)
			return
		else:
			if curr_char == '':  # end of file
				self.file.seek(curr_position)
				return
			curr_position = self.file.tell()
			self.file.seek(curr_position-1)

		if self.peek_next().isspace() or self.peek_next() == "/":
			self.clean_the_current_token()

	def token_type(self):
		"""
		returns the type of the current token, as a constant
\		"""
		return self.curr_token_type

	def keyWord(self):
		"""
		returns the keyword which is the current token, as a constant.
		this method should be called only if tokenType is KEYWORD
		"""
		return self.curr_token

	def symbol(self):
		"""
		returns the character which is the current token. should be called only if tokenType is
		symbol
		"""
		return self.curr_token

	def identifier(self):
		"""
		returns the integer value of the current token. should be called only if tokenType is
		IDENTIFIER
		"""
		return self.curr_token

	def intVal(self):
		"""
		returns the integer value of the current token. should be called only if tokenType is
		INT_CONST
		"""
		return self.curr_token

	def stringVal(self):
		"""
		returns the string value of the current token, without the two enclosing double quotes.
		should be called only if tokenType is STRING_CONST.
		"""
		return self.curr_token