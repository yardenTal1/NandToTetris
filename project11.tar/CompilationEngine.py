from SymbolTable import *

class CompilationEngine:
	"""
	this class generates the compiler's output.
	"""

	OP = ["+", "-", "*", "/", "&", "|", "<", ">", "="]
	CONST_KEYWORD = ["true", "false", "null", "this"]
	UNARY_OP = ["-", "~"]
	KINDS = {"VAR": "local", "STATIC":"static", "ARG":"argument", "FIELD":"this",
			 "None":"None"}
	STATEMENTS = ["let", "if", "while", "do", "return"]


	def __init__(self, tokenizer, vm_writer):
		"""
		creates a new compilation engine with the given input and output.
		"""
		self.tokenizer = tokenizer
		self.vm_writer = vm_writer
		self.symbol_table = SymbolTable()
		self.class_name = ""
		self.count_if = 0
		self.count_while = 0
		self.count_args_num = 0
		# self.output_file = output_file

	def compile_class(self):
		"""
		compiles a complete class.
		"""
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# skip "class"
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.class_name = self.tokenizer.identifier()

		# skip class name
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# skip "{"
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		while self.tokenizer.token_type() == "KEYWORD" and (self.tokenizer.keyWord() == "field"
															or self.tokenizer.keyWord() == "static"):
			self.compile_class_var_dec()
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		while self.tokenizer.token_type() == "KEYWORD" and (
					self.tokenizer.keyWord() == "constructor"
			or self.tokenizer.keyWord() == "function" or self.tokenizer.keyWord() == "method"):
			self.compile_subroutine_dec()

		# need to close the file in the end of this function with vmWriter.close()
		self.vm_writer.close()

	def compile_class_var_dec(self):
		"""
		compiles a static variable declaration, or a field declaration.
		"""
		kind = self.tokenizer.keyWord()

		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		if self.tokenizer.token_type() == "IDENTIFIER":
			type = self.tokenizer.identifier()  # the type is an object
		else:
			type = self.tokenizer.keyWord()

		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		varName = self.tokenizer.identifier()
		# add a class var to the symbol table
		self.symbol_table.define(varName, type, kind.upper())
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# If this is a declaration of several variables
		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			varName = self.tokenizer.identifier()
			# add a class var to the symbol table
			self.symbol_table.define(varName, type, kind.upper())
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			# In the last time its skip on thr ";"

	def compile_subroutine_dec(self):
		"""
		compiles a complete method, function, or constructor.
		"""
		self.count_if = 0
		self.count_while = 0
		self.symbol_table.start_subroutine()

		# constructor / function / method
		subroutine_kind = self.tokenizer.keyWord()

		# skip return type
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		# name
		subroutine_name = self.tokenizer.identifier()
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# skip (
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# handel parameters
		if subroutine_kind == "method":
			self.symbol_table.define("this", self.class_name, "argument")
		self.compile_parameter_list()

		# skip )
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.compile_subroutine_body(subroutine_name, subroutine_kind)

	def compile_parameter(self):
		var_type = self.get_type()

		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		var_name = self.tokenizer.identifier()
		self.symbol_table.define(var_name, var_type, "ARG")

	def get_type(self):
		if self.tokenizer.token_type() == "KEYWORD":
			return self.tokenizer.keyWord()
		else:
			return self.tokenizer.identifier()

	def compile_parameter_list(self):
		"""
		compiles a (possibly empty) parameter list. does not handle the enclosing "()".
		"""
		# skip (
		# if self.tokenizer.has_more_tokens():
		# 	self.tokenizer.advance()

		if self.tokenizer.symbol() != ")":
			self.compile_parameter()
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
				# skip ,
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_parameter()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()


	def compile_subroutine_body(self, subroutine_name, subroutine_kind):
		"""
		compiles a subroutine's body.
		"""
		# skip {
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		while self.tokenizer.token_type() == "KEYWORD" and self.tokenizer.keyWord() == "var":
			self.compile_var_dec()

		count_local = self.symbol_table.var_count("VAR")
		if (count_local == None):
			count_local = 0
		self.vm_writer.write_function(self.class_name + "." + subroutine_name, count_local)

		# if the subroutine is method, set the VM THIS to the given argument 0
		if subroutine_kind == "method":
			self.vm_writer.write_push("argument", 0)
			self.vm_writer.write_pop("pointer", 0)

		# if the subroutine is constructor, handle memory allocation.
		if subroutine_kind == "constructor":
			count_filed = self.symbol_table.var_count("FIELD")
			self.vm_writer.write_push("constant", count_filed)
			self.vm_writer.write_call("Memory.alloc", 1)
			self.vm_writer.write_pop("pointer", 0)

		self.compile_statements()

		# skip }
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

	def compile_var_dec(self):
		"""
		compiles a var declaration.
		"""
		# skip var
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# type
		var_type = self.get_type()

		# name
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		var_name = self.tokenizer.identifier()

		self.symbol_table.define(var_name, var_type, "VAR")
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
			# skip ,
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			var_name = self.tokenizer.identifier()

			self.symbol_table.define(var_name, var_type, "VAR")
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# skip ;
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

	def compile_statements(self):
		"""
		compiles a sequence of statements. does not handle the enclosing "()".
		"""
		while self.tokenizer.keyWord() in self.STATEMENTS:
			if self.tokenizer.keyWord() == "let":
				self.compile_let()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.keyWord() == "if":
				self.compile_if()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.keyWord() == "while":
				self.compile_while()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.keyWord() == "do":
				self.compile_do()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
			elif self.tokenizer.keyWord() == "return":
				self.compile_return()
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()

	def compile_let(self):
		"""
		compiles a let statement.
		"""
		# skip let
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		var_kind = self.KINDS[self.symbol_table.kind_of(self.tokenizer.identifier())]
		var_index = self.symbol_table.index_of(self.tokenizer.identifier())

		# skip var name
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		if self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == "=":
			# skip =
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.compile_expression()
			self.vm_writer.write_pop(var_kind, var_index)

			# # skip ;
			# if self.tokenizer.has_more_tokens():
			# 	self.tokenizer.advance()
		elif self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == "[":
			# skip [
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.vm_writer.write_push(var_kind, var_index)  # push arr
			self.compile_expression()
			self.vm_writer.write_arithmetic("add")

			# skip ]
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			# skip =
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.compile_expression()  # push exp2

			self.vm_writer.write_pop("temp", 0)  # temp 0 = value of exp 2
			self.vm_writer.write_pop("pointer", 1)
			self.vm_writer.write_push("temp", 0)
			self.vm_writer.write_pop("that", 0)

			# # skip ;
			# if self.tokenizer.has_more_tokens():
			# 	self.tokenizer.advance()


	def compile_if(self):
		"""
		compiles an id statement, possibly with a trailing else clause.
		"""
		if_false_label = "IF_FALSE_" + str(self.count_if)
		if_true_label = "IF_TRUE_" + str(self.count_if)
		end_if_label = "END_IF_" + str(self.count_if)
		self.count_if += 1
		# skip if
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# skip (
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.compile_expression()

		# skip )
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.vm_writer.write_if(if_true_label)
		self.vm_writer.write_goto(if_false_label)

		# skip {
		self.vm_writer.write_label(if_true_label)
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.compile_statements()

		if self.tokenizer.token_type() == "KEYWORD" and self.tokenizer.keyWord() == "else":
			self.vm_writer.write_goto(end_if_label)
			# skip else
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.vm_writer.write_label(if_false_label)

			# skip {
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.compile_statements()
			self.vm_writer.write_label(end_if_label)
		else:
			self.vm_writer.write_label(if_false_label)

	def compile_while(self):
		"""
		compiles a while statement.
		"""
		while_label = "WHILE_" + str(self.count_while)
		while_end_label = "WHILE_END_" + str(self.count_while)
		self.count_while += 1
		# print label
		self.vm_writer.write_label(while_label)  # print "label WHILE_START"

		# skip "while"
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		# skip "("
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.compile_expression()
		self.vm_writer.write_arithmetic("not")
		self.vm_writer.write_if(while_end_label)  # print "if goto WHILE_END"

		# skip ")"
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		# skip "{"
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		self.compile_statements()
		# skip "}"
		self.vm_writer.write_goto(while_label)  # print "goto WHILE_START"
		self.vm_writer.write_label(while_end_label)  # print "label WHILE_END"


	def compile_subroutine_call(self):
		"""
		compiles a subroutine call.
		"""
		name = self.tokenizer.identifier()
		kind = self.KINDS[self.symbol_table.kind_of(name)]

		# skip . if object / method name
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		# compile func(..)
		if self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == "(":
			# skip (
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()
			self.vm_writer.write_push('pointer', 0)

			self.compile_expression_list()

			self.count_args_num += 1
			self.vm_writer.write_call(self.class_name + "." + name, self.count_args_num)

			# skip )
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

		# compile obj.func(..)
		elif self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ".":
			# skip .
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			subroutine_name = self.tokenizer.identifier()
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			# push object
			if kind != "None": # if the kind is None its a function call
				obj_index = self.symbol_table.index_of(name)
				name = self.symbol_table.type_of(name)
				self.vm_writer.write_push(kind, obj_index)

			# skip (
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()

			self.compile_expression_list()
			if kind != "None":
				self.count_args_num += 1 # include the object

			self.vm_writer.write_call(name + "." + subroutine_name, self.count_args_num)

			# skip )
			if self.tokenizer.has_more_tokens():
				self.tokenizer.advance()


	def compile_do(self):
		"""
		compiles a do statement.
		"""
		# skip do
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()

		self.compile_subroutine_call()

		self.vm_writer.write_pop("temp", 0)  # pop the meaningless return value


	def compile_return(self):
		"""
		compiles a return statement.
		"""
		if self.tokenizer.has_more_tokens():
			self.tokenizer.advance()
		if self.tokenizer.symbol() != ";":
			self.compile_expression()
		else:  # void function return 0
			self.vm_writer.write_push("constant", 0)
		self.vm_writer.write_return()

	def compile_expression(self):
		"""
		compiles an expression.
		"""
		self.compile_term()
		while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() in self.OP:
			output_op = self.tokenizer.symbol()
			if output_op == "=":
				output_op = "eq"
			elif output_op == ">":
				output_op = "gt"
			elif output_op == "<":
				output_op = "lt"
			elif output_op == "|":
				output_op = "or"
			elif output_op == "&":
				output_op = "and"
			elif output_op == "/":
				output_op = "divide"
			elif output_op == "*":
				output_op = "mult"
			elif output_op == "-":
				output_op = "sub"
			elif output_op == "+":
				output_op = "add"
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()
			self.compile_term()
			self.vm_writer.write_arithmetic(output_op)

	def compile_term(self):
		"""
		compiles an term. if the current token is an identifier, the routine must distinguish
		between a variable, an array entry, or a subroutine call. a single look-ahead token,
		which may be ont of "[","(", or ".", suffices to distinguish between the possibilities.
		any other token is not part of this trem and should be advanced over.
		"""
		if self.tokenizer.token_type() == "INT_CONST":
			self.vm_writer.write_push("constant", self.tokenizer.intVal())
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()

		elif self.tokenizer.token_type() == "STRING_CONST":
			# למה אלעד מחק את כל ה\t
			string = self.tokenizer.stringVal()
			self.vm_writer.write_push("constant", len(string))
			self.vm_writer.write_call("String.new", 1)
			for c in string:
				# integer representing the Unicode code
				self.vm_writer.write_push("constant", ord(c))
				self.vm_writer.write_call("String.appendChar", 2)
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()

		elif self.tokenizer.token_type() == "KEYWORD" and (self.tokenizer.keyWord() in
															  self.CONST_KEYWORD):
			keyword = self.tokenizer.keyWord()
			if keyword == "true":
				self.vm_writer.write_push("constant", 1)
				self.vm_writer.write_arithmetic("neg")
			elif keyword == "null":
				self.vm_writer.write_push("constant", 0)
			elif keyword == "false":
				self.vm_writer.write_push("constant", 0)
			elif keyword == "this":
				self.vm_writer.write_push("pointer", 0)
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()

		elif self.tokenizer.token_type() == "IDENTIFIER":
			name = self.tokenizer.identifier()
			kind = self.KINDS[self.symbol_table.kind_of(name)]
			index = self.symbol_table.index_of(name)
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()

			# if its varName '[' expression ']'
			if self.tokenizer.token_type() == "SYMBOL":
				if self.tokenizer.symbol() == "[":
					# skip "["
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()
					self.compile_expression()
					# skip "]"
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()
					self.vm_writer.write_push(kind, index)
					self.vm_writer.write_arithmetic("add")
					self.vm_writer.write_pop("pointer", 1)
					self.vm_writer.write_push("that", 0)

				# subroutineName '(' expressionList ')' -  just in the class of this function
				elif self.tokenizer.symbol() == "(":
					# skip "("
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()
					self.vm_writer.write_push('pointer', 0)
					self.compile_expression_list()
					self.count_args_num += 1
					self.vm_writer.write_call(self.class_name + "." + name, self.count_args_num)
					# skip ")"
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()

				# function call - className |varName) '.' subroutineName '(' expressionList ')'
				elif self.tokenizer.symbol() == ".":
					# skip "."
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()
					subroutine_name = self.tokenizer.identifier()
					# skip "("
					if self.tokenizer.has_more_tokens:
						self.tokenizer.advance()
					if kind != "None":
						# push object
						obj_index = self.symbol_table.index_of(name)
						name = self.symbol_table.type_of(name)
						self.vm_writer.write_push(kind, obj_index)
						# skip (
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()

					self.compile_expression_list()
					if kind != "None":
						self.count_args_num += 1  # include the object
					self.vm_writer.write_call(name + "." + subroutine_name,
												  self.count_args_num)
					# skip )
					if self.tokenizer.has_more_tokens():
						self.tokenizer.advance()
				else:  # the term is of the form - varName
					self.vm_writer.write_push(kind, index)

			# '(' expression ')'
		elif self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == "(":
			# skip "("
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()
			self.compile_expression()
			# skip ")"
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()
		# unaryOp term
		elif self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() in self.UNARY_OP:
			unary_op = self.tokenizer.symbol()
			if self.tokenizer.symbol() == '-':
				unary_op = "neg"
			elif self.tokenizer.symbol() == '~':
				unary_op = "not"
			# skip - / ~
			if self.tokenizer.has_more_tokens:
				self.tokenizer.advance()
			self.compile_term()
			self.vm_writer.write_arithmetic(unary_op)

	def compile_expression_list(self):
		"""
		compiles a (possibly empty) comma-separated list of expressions.
		"""
		self.count_args_num = 0
		if (self.tokenizer.token_type() == "INT_CONST") or (self.tokenizer.token_type() ==
			"STRING_CONST") or (self.tokenizer.token_type() == "KEYWORD") or (
				self.tokenizer.token_type() == "IDENTIFIER") or (self.tokenizer.token_type() ==
				"SYMBOL" and (self.tokenizer.symbol() == "(" or self.tokenizer.symbol() in
			self.UNARY_OP)):
			self.compile_expression()
			self.count_args_num += 1

			while self.tokenizer.token_type() == "SYMBOL" and self.tokenizer.symbol() == ",":
				if self.tokenizer.has_more_tokens():
					self.tokenizer.advance()
				self.compile_expression()
				self.count_args_num += 1








