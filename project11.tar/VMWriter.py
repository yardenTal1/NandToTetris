class VMWriter:
	"""
	This class writes VM commands into a file.
	"""

	def __init__(self, output_file):
		"""
		creates a new output .vm file ans prepares it for writing.
		"""
		self.output_file = output_file

	def write_push(self, segment, index):
		"""
		writes a VM push command.
		:param segment: the given segment (CONST, ARG, LOCAL, STATIC, THIS, THAT, POINTER, TEMP)
		:param index: the given index (int)
		"""
		self.output_file.write("push " + segment + " " + str(index) + "\n")

	def write_pop(self, segment, index):
		"""
		writes a VM pop command.
		:param segment: the given segment (CONST, ARG, LOCAL, STATIC, THIS, THAT, POINTER, TEMP)
		:param index: the given index (int)
		"""
		self.output_file.write("pop " + segment + " " + str(index) + "\n")

	def write_arithmetic(self, command):
		"""
		writes a VM arithmetic-logical command.
		:param command: the given command (ADD, SUB, NEG, EQ, GT, LT, ANS, OR, NOT)
		"""
		if command == "mult":
			self.write_call("Math.multiply", 2)
		elif command == "divide":
			self.write_call("Math.divide", 2)
		else:
			self.output_file.write(command + "\n")

	def write_label(self, label):
		"""
		writes a VM label command.
		:param label: the given label (string)
		"""
		self.output_file.write("label " + label + "\n")

	def write_goto(self, label):
		"""
		write a VM goto command.
		:param label: the given label (string)
		"""
		self.output_file.write("goto " + label + "\n")

	def write_if(self, label):
		"""
		write a VM if-goto command.
		:param label: the given label (string)
		"""
		self.output_file.write("if-goto " + label + "\n")

	def write_call(self, name, n_args):
		"""
		writes a VM call command
		:param name: the function name.
		:param n_rgs: the amount of args.
		"""
		self.output_file.write("call " + name + " " + str(n_args) + "\n")

	def write_function(self, name, n_locals):
		"""
		writes a VM function command.
		:param name: the function name.
		:param n_locals: the amount of args.
		"""
		self.output_file.write("function " + name + " " + str(n_locals) + "\n")

	def write_return(self):
		"""
		writes a VM return command.
		"""
		self.output_file.write("return\n")

	def close(self):
		"""
		closes the output file.
		"""
		self.output_file.close()

