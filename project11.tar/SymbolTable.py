class SymbolTable:
	"""
	This class represent a symbol table.
	"""

	def __init__(self):
		"""
		create a new symbol table
		"""
		self.count_arg = 0
		self.count_local = 0
		self.count_static = 0
		self.count_field = 0
		self.class_scope = {}
		self.subroutine_scope = {}

	def start_subroutine(self):
		"""
		start a new subroutine scope (i.e. resets the subroutine's symbol table).
		:return:
		"""
		self.subroutine_scope = {}
		self.count_local = 0
		self.count_arg = 0


	def define(self, name, type, kind):
		"""
		defines a new identifier of the given name, type, and kind, and assigns it a running index.
		STATIC and FIELD identifiers have a class scope, while ARG and VAR identifiers have a
		subroutine scope.
		:param name: the given name (string)
		:param type: the given type (string)
		:param kind: the given kind (STATIC, FIELD, ARG or VAR)
		"""
		if kind == "STATIC":
			self.class_scope[name] = [type, kind, self.count_static]
			self.count_static += 1
		elif kind == "FIELD":
			self.class_scope[name] = [type, kind, self.count_field]
			self.count_field += 1
		elif kind == "ARG":
			self.subroutine_scope[name] = [type, kind, self.count_arg]
			self.count_arg += 1
		elif kind == "VAR":
			self.subroutine_scope[name] = [type, kind, self.count_local]
			self.count_local += 1

	def var_count(self, kind):
		"""
		returns the number of variables of the given kind already defined in the current scope.
		:param kind: the given kind (STATIC, FIELD, ARG or VAR)
		"""
		if kind == "STATIC":
			return self.count_static
		elif kind == "FIELD":
			return self.count_field
		elif kind == "ARG":
			return self.count_arg
		elif kind == "VAR":
			return self.count_local

	def kind_of(self, name):
		"""
		returns the kind of the named identifier in the current scope. if the identifier is
		unknown in the current scope, returns NONE.
		:param name: the given name (string)
		"""
		if name in self.subroutine_scope:
			return self.get_kind("subroutine_scope", name)
		elif name in self.class_scope:
			return self.get_kind("class_scope", name)
		else:
			return "None"

	def type_of(self, name):
		"""
		returns the type of the named identifier in the current scope.
		:param name: the given name (string)
		"""
		if name in self.subroutine_scope:
			return self.get_type("subroutine_scope", name)
		elif name in self.class_scope:
			return self.get_type("class_scope", name)
		else:
			return "None"

	def index_of(self, name):
		"""
		returns the index of the named identifier in the current scope.
		:param name the given name (string)
		"""
		if name in self.subroutine_scope:
			return self.get_index("subroutine_scope", name)
		elif name in self.class_scope:
			return self.get_index("class_scope", name)
		else:
			return "None"

	def get_type(self, scope, name):
		"""
		A function that returns the type of of the named identifier in the current scope
		:param scope:
		:param name:
		"""
		if scope == "subroutine_scope":
			return self.subroutine_scope[name][0]
		return self.class_scope[name][0]

	def get_kind(self,scope,  name):
		"""
		A function that returns the kind of of the named identifier in the current scope
		:param scope:
		:param name:
		:return:
		"""
		if scope == "subroutine_scope":
			return self.subroutine_scope[name][1]
		return self.class_scope[name][1]
	
	def get_index(self, scope, name):
		"""
		A function that returns the index of of the named identifier in the current scope
		:param scope:
		:param name:
		:return:
		"""
		if scope == "subroutine_scope":
			return self.subroutine_scope[name][2]
		return self.class_scope[name][2]






