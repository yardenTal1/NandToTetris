
class SymbolTable:
    """
    Implementation of a symbol table : serves as a dictionary that attaches
    addresses in memory or ROM for names of labels or variables
    """

    # the first address in memory for variables
    FIRST_PLACE = 16

    def __init__(self):
        """
        Constructor: Initializes a new symbol table and inserts the predefined symbol, and sets the address_available -
        the next address for a variable to be 16.
        """
        self.symbolTable = {"SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
                            "R0": 0, "R1": 1, "R2": 2, "R3": 3, "R4": 4,
                            "R5": 5, "R6": 6, "R7": 7, "R8": 8, "R9": 9,
                            "R10": 10, "R11": 11, "R12": 12, "R13": 13,
                            "R14": 14, "R15":15, "SCREEN": 16384, "KBD": 24576}
        self.address_available = self.FIRST_PLACE

    def add_new_symbol(self, symbol, address):
        """
        The function adds a new symbol to the table
        :param symbol: the symbol to add
        :param address: the address in memory
        :return:
        """
        self.symbolTable[symbol] = address

    def contains (self, symbol):
        """
        The function checks whether the given symbol exists in the table
        :param symbol: the symbol that we want to check if exists
        :return: true if exists, otherwise false
        """
        if symbol in self.symbolTable.keys():
            return True
        else:
            return False

    def get_address(self, symbol):
        """
        The function returns the address of the given symbol
        :param symbol: the symbol that we want his address
        :return: the address of the given symbol
        """
        return self.symbolTable[symbol]

    def get_available_address(self):
        """
        The function return the available address for a variable and increments the value for the next time
        :return: the available address for a variable
        """
        self.address_available += 1
        return self.address_available - 1


