from Parser import *
from Code import *
from SymbolTable import *
import sys
import os

A_INSTRUCTION = 0
C_INSTRUCTION = 1
L_COMMAND = 2

MIN_ARG = 2
ASM_FILE = ".asm"
HACK_FILE = ".hack"


def translate_file(file_path):
	"""
	The function converts a file that is written in the assembly language into a file that is written in the hack
	language.
	:param file_path: the address of the file we want to convert
	"""
	# initialization
	input_file = open(file_path, "r")
	output_file = open(file_path[:-4] + HACK_FILE, "w")  # the output file have the same name of the input file
	symbol_table = SymbolTable()
	parser = Parser(input_file)
	count_line = 0  # The counter does not count profit lines, comment lines, and rows of label.

	# first pass
	first_pass(parser, symbol_table, count_line)

	# go the the beginning of the file
	parser.reset_file()

	# second pass
	second_pass(parser, symbol_table, output_file)

	input_file.close()
	output_file.close()


def first_pass(parser, symbol_table, count_line):
	"""
	Initial transition to the file where the labels are placed in the symbol table.
	:param parser: Object Parser
	:param symbol_table: the symbol table
	:param count_line: the number of rows (not including space/comment lines) that we have read so far in the file
	"""
	while parser.advance():
		if parser.get_type() == L_COMMAND:
			l_command = parser.get_l_value()
			symbol_table.add_new_symbol(l_command, count_line)
			continue  # Do not count label lines
		count_line += 1


def second_pass(parser, symbol_table, output_file):
	"""
	A second pass on the file where each line (not including  comment/space lines) is translated into a hack
	language, and input of the translated line into the output file.
	:param parser: Object Parser
	:param symbol_table: the symbol table
	:param output_file: the file to which we will insert the rows after conversion to the hack language
	"""
	while parser.advance():
		line_type = parser.get_type()
		# A instruction
		if line_type == A_INSTRUCTION:
			symbol = parser.get_a_value()
			if symbol.isdigit(): # if its digit - convert it to binary number
				binary_value = Code.translate_a_instruction(symbol)
			else:
				if symbol_table.contains(symbol):  # if its symbol in the table symbol - get the decimal value from the
					# table and convert it to binary number
					symbol_value = symbol_table.get_address(symbol)
					binary_value = Code.translate_a_instruction(symbol_value)
				else:  # if its symbol that is not in the table - we will add it to the table and then convert the
					# received value to a binary number.
					symbol_table.add_new_symbol(symbol, symbol_table.get_available_address())
					symbol_value = symbol_table.get_address(symbol)
					binary_value = Code.translate_a_instruction(symbol_value)
		# C instruction
		elif line_type == C_INSTRUCTION:
			comp = parser.get_comp()
			dest = parser.get_dest()
			jump = parser.get_jump()
			binary_value = Code.translate_c_instruction(comp, dest, jump)
		else:
			continue
		output_file.write(binary_value + "\n")


def main():
	file_path = os.path.abspath(sys.argv[1])

	# check if the path is path to file or to directory
	if os.path.isdir(file_path):
		for file_name in os.listdir(file_path):
			if file_name.endswith(ASM_FILE):
				translate_file(file_path + "\\" + file_name)
			else:
				continue
	elif file_path.endswith(ASM_FILE):
		translate_file(file_path)


if __name__ == "__main__":
	main()
