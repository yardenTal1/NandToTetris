class Parser:
	# the Parser class breaks assembly command

	A_INSTRUCTION = 0
	C_INSTRUCTION = 1
	L_COMMAND = 2
	NULL_STRING = "null"

	def __init__(self, file):
		"""
		The constructor gets input file and create empty string command to the first line
		:param file:
		"""
		self.file = file
		self.currentLine = ""

	def advance(self):
		"""
		The function checks whether there are more commands to read in the file
		:return: True if there is more command to read or false if there is no more
		"""
		self.currentLine = next(self.file,None)
		if self.currentLine == None:  # check if the current line exist in the file
			return False
		# check if the current line is an empty line or a command line
		self.clean_comment()  # clean all the comment from line
		while (self.currentLine.strip() == '') or (self.currentLine == "") or (self.currentLine == '\n') \
				or (self.currentLine.startswith('//')):
			self.clean_comment() # clean all the comment from line
			self.currentLine = next(self.file,None)
			if self.currentLine == None:
				return False
		return True

	def clean_comment(self):
		"""
		Clean all the comment from line
		"""
		if "//" in self.currentLine:
			self.currentLine = self.currentLine.split('//')[0]

	def clean_string(self, string):
		string = string.replace(" ", "")  # Clear spaces
		string = string.rstrip("\n")  # Clear \n
		string = string.rstrip("\r")
		return string

	def get_type(self):
		"""
		The function checks the type of command in the current line
		:return: 0 for a instruction, 1 for c instruction and 2 for label command
		"""
		self.currentLine = self.clean_string(self.currentLine)
		if self.currentLine.startswith('@'):
			return self.A_INSTRUCTION
		if self.currentLine.startswith('('):
			return self.L_COMMAND
		else:
			return self.C_INSTRUCTION

	def get_a_value(self):
		"""
		:return: The function returns the value of a instruction
		"""
		value = self.currentLine[1:]
		value = self.clean_string(value)
		return value

	def get_l_value(self):
		"""
		:return: The function returns the value of label commend
		"""
		value = self.currentLine
		value = self.clean_string(value)
		value = value[1:-1]
		return value

	def get_dest(self):
		"""
		:return: The function return the "dest" part in C instruction
		"""
		if "=" in self.currentLine:
			index_end = self.currentLine.find('=')
			dest = self.currentLine[:index_end]
			dest = self.clean_string(dest)
			return dest
		return self.NULL_STRING

	def get_jump(self):
		"""
		:return: The function return the "jump" part in C instruction
		"""
		if ";" in self.currentLine:
			jump = self.currentLine.split(';')
			jump[1] = self.clean_string(jump[1])
			return jump[1]
		return self.NULL_STRING

	def get_comp(self):
		"""
		:return: The function return the "comp" part in C instruction
		"""
		if "=" in self.currentLine:
			index_start = self.currentLine.find('=')
			comp = self.currentLine[index_start + 1:]
			comp = self.clean_string(comp)
			return comp
		else:
			index_end = self.currentLine.find(';')
			comp = self.currentLine[:index_end]
			comp = self.clean_string(comp)
			return comp

	def reset_file(self):
		"""
		reset the file - go the the beginning and restert the current line to "" (for the second parsing)
		"""
		self.file.seek(0)
		self.currentLine = ""
