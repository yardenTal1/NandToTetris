LEN_BINARY_NUM = 15
A_INSTRUCTION = 0
C_INSTRUCTION = 1

A_OP_CODE = "0"
C_OP_CODE1 = "111"
C_OP_CODE2 = "101"


class Code:
    """
    This class updates a command and converts it to a binary code - hack language.
    """

    # all possible computations
    comp_table = {"0": "0101010", "1": "0111111", "-1": "0111010", "D": "0001100",
                  "A": "0110000", "M": "1110000", "!D": "0001101", "!A": "0110001",
                  "!M": "1110001", "-D": "0001111", "-A": "0110011", "-M": "1110011",
                  "D+1": "0011111", "A+1": "0110111", "M+1": "1110111", "D-1": "0001110",
                  "A-1": "0110010", "M-1": "1110010", "D+A": "0000010", "D+M": "1000010",
                  "D-A": "0010011", "D-M": "1010011", "A-D": "0000111", "M-D": "1000111",
                  "D&A": "0000000", "D&M": "1000000", "D|A": "0010101", "D|M": "1010101",
                  "D<<": "0110000", "D>>": "0010000", "A<<": "0100000", "A>>": "0000000",
                  "M<<": "1100000", "M>>": "1000000"}

    # all possible destinations
    dest_table = {"null": "000","M": "001", "D": "010", "MD": "011",
                  "A": "100", "AM": "101", "AD": "110", "AMD": "111"}

    # all possible jump commands
    jump_table = {"null": "000", "JGT": "001", "JEQ": "010", "JGE": "011",
                  "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111"}

    @staticmethod
    def dic_to_bin(value):
        """
        The function accepts a string that represents a number and converts it to a number in binary view.
        :param value: value to convert
        :return: the value in binary
        """
        val = int(value)
        return bin(val)[2:]

    @staticmethod
    def translate_c_instruction(comp, dest, jump):
        """
        The function accepts a value of C command (in assembly language), and converts it to its binary value.
        :param comp: the computations part in command
        :param dest: the destination part in command
        :param jump: the jump part in command
        :return: the command in binary form
        """
        if comp[-1] == "<" or comp[-1] == ">":
            binary_string = C_OP_CODE2
        else:
            binary_string = C_OP_CODE1
        binary_string += Code.comp_table[comp]
        binary_string += Code.dest_table[dest]
        binary_string += Code.jump_table[jump]
        return binary_string

    @staticmethod
    def translate_a_instruction(value):
        """
        The function accepts a value of A command (in assembly language), and converts it to its binary value.
        :param value: value in assembly language
        :return: the value in binary form
        """
        binary_string = A_OP_CODE
        binary = Code.dic_to_bin(value)
        for i in range(len(binary), LEN_BINARY_NUM):
            binary_string += "0"
        binary_string += binary
        return binary_string







