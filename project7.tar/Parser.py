"""
parses each VM command into its lexical elements
"""


class Parser:

	C_ARITHMETIC = "arithmetic"
	C_POP = "pop"
	C_PUSH = "push"

	COMMANDS_TYPE = {"add": C_ARITHMETIC , "sub": C_ARITHMETIC, "neg": C_ARITHMETIC,
					 "eq": C_ARITHMETIC, "gt": C_ARITHMETIC, "lt": C_ARITHMETIC,
					 "and": C_ARITHMETIC, "or": C_ARITHMETIC, "not": C_ARITHMETIC, "pop": C_POP,
					 "push": C_PUSH}

	def __init__(self, input_file):
		"""
		open the input file/stream and gets ready to parse it.
		@:param input_file the input file
		"""
		self.file = input_file
		self.count_lines = 0
		self.current_command = ""
		self.commands_array = []
		self.appendAllCommands()  # append all the commands to array
		self.file.close()

	def hasMoreCommands(self):
		"""
		check if are there more commands in the input
		:return: true if there is, otherwise return false
		"""
		if self.count_lines < len(self.commands_array):
			return True
		return False

	def advance(self):
		"""
		reads the text command from the input and make it the current command. Should be called only
		if hasMoreCommands() is true. Initially there is no current command.
		:return:
		# """
		# cur_line = self.commands_array[self.count_lines]
		# self.count_lines += 1
		# if self.hasMoreCommands():
		# 	self.advance()
		# self.current_command = cur_line.split()
		cur_line = self.commands_array[self.count_lines]
		self.count_lines += 1
		self.current_command = cur_line.split()



	def commandType(self):
		"""
		:return: a constant representing the type of the current command. C_ARITHMETIC is returned
		for
		all the arithmetic/logical command.
		"""
		return self.COMMANDS_TYPE[self.current_command[0]]

	def arg1(self):
		"""
		:return: the first argument of the current command. In the case of C_ARITHMETIC, the command \
		itself (add, sub ect.) is returned. Should not be called if the current command is C_RETURN.
		"""
		cur_command_type = self.commandType()
		if cur_command_type == self.C_ARITHMETIC:
			return self.current_command[0]
		else:
			return self.current_command[1]

	def arg2(self):
		"""
		:return: the second argument of  the current command. Should be called only if the current
		command is C_PUSH, C_POP, C_FUNCTION, or C_CALL.
		"""
		return self.current_command[2]

	def appendAllCommands(self):
		"""
		The function scans the file and adds command lines to the array of commands. The function
		ignores the comments lines, space and line decline.
		:return:
		"""
		for line in self.file:
			idx = line.find("//")
			if idx == 0:  # comment line
				continue
			if idx != -1:
				line = line[:idx] # remove comment from line
			line = line.strip()
			if line != '\n' and line != "":  # ignore empty lines and comments lines
				self.commands_array.append(line)






