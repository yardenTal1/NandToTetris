"""
writes the assembly code that implements the parsed command
"""

class CodeWriter:

	C_PUSH = "push"
	C_POP = "pop"

	def __init__(self, output_file):
		"""
		open the output file and gets ready to write into it.
		:param output_file: the output file
		"""
		self.file = output_file
		self.name_file = ""
		self.counter = 0

	def setFileName(self, name):
		"""
		Informs the code writer that the translation of a new VM file is started.
		:param name:  the file name(string)
		"""
		self.name_file = name

	def writeArithmetic(self, command):
		"""
		writes to the output file the assembly code that implements the given arithmetic command.
		@:param command arithmetic command (string)
		"""
		if command == "gt" or command == "lt" or command == "eq":
			self.writeBool(command)
		elif command == "add":
			self.writeLogicExpression("+")
		elif command == "sub":
			self.writeLogicExpression("-")
		elif command == "or":
			self.writeLogicExpression("|")
		elif command == "and":
			self.writeLogicExpression("&")
		elif command == "neg":
			self.negAndNot("-")
		elif command == "not":
			self.negAndNot("!")


	def decrementSP(self):
		"""
		produces the assembly lines for decrement SP on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("M=M-1\n")

	def incrementSP(self):
		"""
		produces the assembly lines for increment SP on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("M=M+1\n")

	def pushTrue(self):
		"""
		produces the assembly lines for true on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=-1\n")

	def pushFalse(self):
		"""
		produces the assembly lines for false on the stack variables
		"""
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=0\n")

	def writeLogicExpression(self, sign):
		"""
		produces the assembly lines for sum, sub, and, or operators on the stack variables
		:param sign: + , -, &, |
		"""
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=M" + sign + "D\n")
		self.incrementSP()

	def negAndNot(self, sign):
		"""
		produces the assembly lines for neg and not operators on the stack variables
		:param sign: !, -
		"""
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=" + sign + "M\n")
		#self.file.write("@SP\n")
		#self.file.write("A=M\n")
		#self.file.write("D=M\n")
		self.incrementSP()

	def writeBool(self, command):
		"""
		produces the assembly lines for boolean operators (> = < ) on the stack variables
		:param command:
		:return:
		"""

		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.file.write("@R13\n") #Y
		self.file.write("M=D\n")
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("D=M\n")
		self.file.write("@R14\n") #X
		self.file.write("M=D\n")
		self.file.write("@R13\n") #Y
		self.file.write("D=M&D\n")
		self.file.write("@R15\n") #X&Y
		self.file.write("M=D\n")
		self.file.write("@SP\n")
		self.file.write("A=M\n")
		self.file.write("M=!M\n")
		self.file.write("D=M\n")
		self.incrementSP()
		self.file.write("A=M\n")
		self.file.write("M=!M\n")
		self.file.write("D=D&M\n")
		self.file.write("@R15\n")
		self.file.write("M=M|D\n")
		self.incrementSP()
		self.file.write("@R15\n")
		self.file.write("D=M\n")
		self.file.write("@SAMESIGN" + command.upper() + str(self.counter) + "\n")
		self.file.write("D;JLE\n")

		self.file.write("(DIFRRENTSIGN" + command.upper() + str(self.counter) + ")\n")
		if command == 'eq':
			self.decrementSP()
			self.decrementSP()
			self.file.write("@SP\n")
			self.file.write("A=M\n")
			self.file.write("M=0\n")
			self.incrementSP()
			self.file.write("@END" + str(self.counter) +"\n")
			self.file.write("0;JMP\n")
		elif command == 'lt':
			self.file.write("@R14\n") #X
			self.file.write("D=M\n")
			self.file.write("@TRUE" + str(self.counter) + "\n")
			self.file.write("D;JLT\n")
			self.file.write("@FALSE" + str(self.counter) + "\n")
			self.file.write("D;JGE\n")
		elif command == 'gt':
			self.file.write("@R14\n") #X
			self.file.write("D=M\n")
			self.file.write("@FALSE" + str(self.counter) + "\n")
			self.file.write("D;JLT\n")
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JGE\n")

		self.file.write("(SAMESIGN" + command.upper() + str(self.counter) + ")\n")
		if command == 'eq':
			self.file.write("@R13\n")
			self.file.write("D=M\n") #D=Y
			self.file.write("@R14\n")
			self.file.write("D=M-D\n") #D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JEQ\n")
		elif command == 'lt':
			self.file.write("@R13\n")
			self.file.write("D=M\n") #D=Y
			self.file.write("@R14\n")
			self.file.write("D=M-D\n")  # D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JLT\n")
		elif command == 'gt':
			self.file.write("@R13\n")
			self.file.write("D=M\n") #D=Y
			self.file.write("@R14\n")
			self.file.write("D=M-D\n")  # D=X-Y
			self.file.write("@TRUE" + str(self.counter) +"\n")
			self.file.write("D;JGT\n")

		self.file.write("(FALSE" + str(self.counter) + ")\n")
		self.decrementSP()
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=0\n")
		self.incrementSP()
		self.file.write("@END" + str(self.counter) + "\n")
		self.file.write("0;JMP\n")
		self.file.write("(TRUE" + str(self.counter) + ")\n")
		self.decrementSP()
		self.decrementSP()
		self.file.write("A=M\n")
		self.file.write("M=-1\n")
		self.incrementSP()
		self.file.write("@END" + str(self.counter) + "\n")
		self.file.write("0;JMP\n")
		self.file.write("(END" + str(self.counter) + ")\n")
		self.counter += 1

	def writePushPop(self, command, segment, index):
		"""
		writes to the output file the assembly code that implements the given command, where command is either
		C_PUSH or C_POP
		:param command:  C_PUSH or C_POP command (string)
		:param segment: segment to write to (string)
		:param index: location in the segment (int)
		"""
		index = int(index)
		four_similar_segments ={"local" : "@LCL", "argument" : "@ARG", "this" : "@THIS", "that": "@THAT"}
		if command == self.C_PUSH:
			if segment in four_similar_segments:
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=A\n")
				self.file.write(four_similar_segments[segment] + "\n")
				self.file.write("D=D+M\n")
				self.file.write("A=D\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "constant":
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=A\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "temp":
				self.file.write("@" + str(index + 5) + "\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "static":
				self.file.write("@" + self.name_file + "." + str(index) + "\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()
			elif segment == "pointer":
				if index == 0:
					self.file.write("@THIS\n")
				elif index == 1:
					self.file.write("@THAT\n")
				self.file.write("D=M\n")
				self.file.write("@SP\n")
				self.file.write("A=M\n")
				self.file.write("M=D\n")
				self.incrementSP()

		if command == self.C_POP:
			if segment in four_similar_segments:
				self.file.write(four_similar_segments[segment] + "\n")
				self.file.write("D=M\n")
				self.file.write("@" + str(index) + "\n")
				self.file.write("D=D+A\n")
				self.file.write("@R13\n") #general purpose registers
				self.file.write("M=D\n")
				self.decrementSP()
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@R13\n")  # general purpose registers
				self.file.write("A=M\n")
				self.file.write("M=D\n")

			elif segment == "temp":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@" + str(index + 5) + "\n")
				self.file.write("M=D\n")
			elif segment == "static":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				self.file.write("@" + self.name_file + "." + str(index) + "\n")
				self.file.write("M=D\n")
			elif segment == "pointer":
				self.file.write("@SP\n")
				self.file.write("M=M-1\n")
				self.file.write("A=M\n")
				self.file.write("D=M\n")
				if index == 0:
					self.file.write("@THIS\n")
				elif index == 1:
					self.file.write("@THAT\n")
				self.file.write("M=D\n")


	def close(self):
		"""
		closes the output file
		"""
		self.file.close()