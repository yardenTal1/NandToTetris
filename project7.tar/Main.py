"""
drives the process (VMTranslator)
"""

import sys
import os
from Parser import *
from CodeWriter import *

VM_FILE = '.vm'
ASM_FILE = '.asm'


class Main:

	def __init__(self, parser, codeWriter):
		self.parser = parser
		self.codeWriter = codeWriter

	def translate_file(self):
		"""
		the function translate vm files to asm file.
		"""
		while self.parser.hasMoreCommands():
			self.parser.advance()
			command_type = self.parser.commandType()
			arg1 = self.parser.arg1()
			if command_type == self.parser.C_ARITHMETIC:
				self.codeWriter.writeArithmetic(arg1)
			else:
				arg2 = self.parser.arg2()
				self.codeWriter.writePushPop(command_type, arg1, arg2)


def main():
	file_path = os.path.abspath(sys.argv[1])

	#check if the path is path to file or to directory
	if os.path.isdir(file_path):
		files = [os.path.join(file_path, file) for file in os.listdir(file_path) if
				 file.endswith(VM_FILE) and os.path.isfile(os.path.join(file_path,file))]
		dir_name = os.path.basename(os.path.normpath(file_path))
		output_file = open(os.path.join(file_path, dir_name + ASM_FILE), "w")
	else:
		files = [file_path]
		output_file = open(file_path[:-3] + ASM_FILE, "w")

	codeWriter = CodeWriter(output_file)
	for input_file in files:
		file = open(input_file, "r")
		codeWriter.setFileName(os.path.basename(input_file)[:-3])
		parser = Parser(file)
		main = Main(parser, codeWriter)
		main.translate_file()
		file.close()
	codeWriter.close()



if __name__ == "__main__":
	main()